// import the schedules and they will be auto-registered
// import FetchDataSchedule from "./FetchDataSchedule";

// register the schedule command by providing the execution frequency
// const fetchDataSchedule = new FetchDataSchedule('0 */10 * * * *');