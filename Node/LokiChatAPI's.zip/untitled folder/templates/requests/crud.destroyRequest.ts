import {
    IsDefined
} from 'class-validator';

export class templateNameDestroyRequest {
    // @IsDefined()
    // email!:     string;

    constructor(request) {
       // this.email      = request?.body?.email;
    }
}