import {
    IsDefined
} from 'class-validator';

export class templateNameUpdateRequest {
    // @IsDefined()
    // email!:     string;

    constructor(request) {
       // this.email      = request?.body?.email;
    }
}