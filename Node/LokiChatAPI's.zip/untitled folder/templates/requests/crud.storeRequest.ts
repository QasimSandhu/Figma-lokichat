import {
    IsDefined
} from 'class-validator';

export class templateNameStoreRequest {
    // @IsDefined()
    // email!:     string;

    constructor(request) {
       // this.email      = request?.body?.email;
    }
}