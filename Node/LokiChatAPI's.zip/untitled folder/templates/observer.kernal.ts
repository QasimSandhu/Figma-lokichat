// import UserCreateObserver from './UserSaveObserver';

// const observer = new UserCreateObserver();
// observer.observe();