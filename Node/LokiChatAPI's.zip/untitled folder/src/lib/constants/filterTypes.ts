export const SEARCH_FILTER = {
    TODAY: 'today',
    LAST_WEEK: 'lastWeek',
    PREVIOUS_MONTH: 'last30Days',
    OLDER: 'older'
}