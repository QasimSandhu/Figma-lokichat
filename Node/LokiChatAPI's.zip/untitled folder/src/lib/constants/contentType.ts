export const CONTENT_TYPE = {
    AUDIO: 'audio/mpeg',
    IMAGE: 'image/jpeg',
    FILE: 'text/plain'
}