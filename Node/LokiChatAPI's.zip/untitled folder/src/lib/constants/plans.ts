export const PLAN_TYPE = {
    BASIC:'Basic',
    PREMIUM:'Premium',
    PRO:'Pro'
}