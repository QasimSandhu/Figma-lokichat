export const ROUTES = {
    DEBATE: "/debate",
}