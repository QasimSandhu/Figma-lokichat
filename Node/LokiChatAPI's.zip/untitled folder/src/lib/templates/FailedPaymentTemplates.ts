const template = (name:string) => {
    return ``
} 
export default template;