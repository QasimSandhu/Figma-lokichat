export default interface IInvitedSuperUser extends Document {
    name: string;
    email: any;
    invitationCode:any
  }
  