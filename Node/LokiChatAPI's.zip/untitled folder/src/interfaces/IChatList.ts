export default interface IChatList extends Document {
  id: string;
  user: any;
  title: string;
  color: string;
}