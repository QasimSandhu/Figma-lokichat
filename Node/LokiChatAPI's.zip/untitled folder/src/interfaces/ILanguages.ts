export default interface ILanguages extends Document {
    code: string;
    gender: any;
    title:any
    languageName:any
  }
  